
function imprime(){
    let lg = document.getElementyById("login").value
    let ps = document.getElementyById("pass").value

    let senha = "snoopy"

    if(ps == senha){
        alert("Você está logado!")
    } else {
        alert("Tente novamente.")
    }

}

